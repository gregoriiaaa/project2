package proj2

// You MUST NOT change these default imports.  ANY additional imports it will
// break the autograder and everyone will be sad.

import (
	_ "encoding/hex"
	_ "encoding/json"
	_ "errors"
	"reflect"
	_ "strconv"
	_ "strings"
	"testing"

	"github.com/cs161-staff/userlib"
	"github.com/google/uuid"
	_ "github.com/google/uuid"
)

func clear() {
	// Wipes the storage so one test does not affect another
	userlib.DatastoreClear()
	userlib.KeystoreClear()
}

func TestInit(t *testing.T) {
	clear()
	t.Log("Initialization test")

	// You can set this to false!
	userlib.SetDebugStatus(false)

	alice, err := InitUser("alice", "fubar")
	if err != nil {
		// t.Error says the test fails
		t.Error("Failed to initialize user", err)
		return
	}
	// t.Log() only produces output if you run with "go test -v"
	// t.Log("Got user", u)

	/* My Tests Start Here */
	//Test throwing error for initializing a user that already exists
	alice2, err := InitUser("alice", "fubar")
	if err == nil {
		t.Error("Failed to throw error for initializing a user that already exists", err)
		return
	}
	_ = alice2

	//Test throwing error for initializing a user with a NOT unique username
	alice3, err := InitUser("alice", "potato")
	if err == nil {
		t.Error("Failed to throw error for initializing a user with a NOT unique username", err)
		return
	}
	_ = alice3

	//Test initializing a user with same password as somebody else
	bob, err := InitUser("bob", "fubar")
	if err != nil {
		t.Error("Failed to initialize a user with same password as somebody else", err)
		return
	}

	//Test Public Keys were successfully Stored
	_, okay := userlib.KeystoreGet(alice.Username + "PKE")
	if !okay {
		t.Error("Failed to save Alice's PKE onto Keystore", err)
		return
	}
	_, okay = userlib.KeystoreGet(bob.Username + "PKE")
	if !okay {
		t.Error("Failed to save Bob's PKE onto Keystore", err)
		return
	}

}

func TestStorage(t *testing.T) {
	clear()
	u, err := InitUser("alice", "fubar")
	if err != nil {
		t.Error("Failed to initialize user", err)
		return
	}

	v := []byte("This is a test")
	u.StoreFile("file1", v)

	v2, err2 := u.LoadFile("file1")
	if err2 != nil {
		t.Error("Failed to upload and download", err2)
		return
	}
	if !reflect.DeepEqual(v, v2) {
		t.Error("Downloaded file is not the same", v, v2)
		return
	}
}

func TestInvalidFile(t *testing.T) {
	clear()
	u, err := InitUser("alice", "fubar")
	if err != nil {
		t.Error("Failed to initialize user", err)
		return
	}

	_, err2 := u.LoadFile("this file does not exist")
	if err2 == nil {
		t.Error("Downloaded a ninexistent file", err2)
		return
	}
}

func TestShare(t *testing.T) {
	clear()

	userlib.SetDebugStatus(false)

	u, err := InitUser("alice", "fubar")
	if err != nil {
		t.Error("Failed to initialize user", err)
		return
	}
	u2, err2 := InitUser("bob", "foobar")
	if err2 != nil {
		t.Error("Failed to initialize bob", err2)
		return
	}

	v := []byte("This is a test")
	u.StoreFile("file1", v)

	var v2 []byte
	var accessToken uuid.UUID

	v, err = u.LoadFile("file1")
	if err != nil {
		t.Error("Failed to download the file from alice", err)
		return
	}

	accessToken, err = u.ShareFile("file1", "bob")
	if err != nil {
		t.Error("Failed to share the a file", err)
		return
	}
	err = u2.ReceiveFile("file2", "alice", accessToken)
	if err != nil {
		t.Error("Failed to receive the share message", err)
		return
	}

	v2, err = u2.LoadFile("file2")
	if err != nil {
		t.Error("Failed to download the file after sharing", err)
		return
	}
	if !reflect.DeepEqual(v, v2) {
		t.Error("Shared file is not the same", v, v2)
		return
	}
}

/*
********************************************
**       	      My Tests        	      **
********************************************
 */

func TestGetSymKeys(t *testing.T) {
	t.Log("GetSymKeys test")

	userlib.SetDebugStatus(false)

	//Test error is thrown for parent key with length that is not 16
	parentKey := userlib.RandomBytes(0)
	_, _, err := getSymKeys(parentKey)
	if err.Error() != Error("Parent Key must have a length of 16.").Error() {
		t.Error("Failed to throw error for empty parent key.")
		return
	}
	parentKey = userlib.RandomBytes(15)
	_, _, err = getSymKeys(parentKey)
	if err.Error() != Error("Parent Key must have a length of 16.").Error() {
		t.Error("Failed to throw error for parent key of length 15.")
		return
	}
	parentKey = userlib.RandomBytes(17)
	_, _, err = getSymKeys(parentKey)
	if err.Error() != Error("Parent Key must have a length of 16.").Error() {
		t.Error("Failed to throw error for parent key of length 17.")
		return
	}

	//Test determinism
	parentKey = userlib.RandomBytes(16)
	ek1, mk1, _ := getSymKeys(parentKey)
	ek2, mk2, _ := getSymKeys(parentKey)
	if !reflect.DeepEqual(ek1, ek2) || !reflect.DeepEqual(mk1, mk2) {
		t.Error("Failed to deterministically create encryption and mac key from parent key.")
		return
	}
	//Test length of keys
	if len(ek1) != userlib.AESKeySizeBytes {
		t.Error("Failed to create encryption key with corret size of AESKeySize = 16.")
		return
	}
	if len(mk1) != userlib.AESKeySizeBytes {
		t.Error("Failed to create mac key with corret size of AESKeySize = 16.")
		return
	}

	//Test two different parent keys created different encryption and mac keys
	parentKey1 := userlib.RandomBytes(16)
	parentKey2 := userlib.RandomBytes(16)
	ek1, mk1, _ = getSymKeys(parentKey1)
	ek2, mk2, _ = getSymKeys(parentKey2)
	if reflect.DeepEqual(ek1, ek2) || reflect.DeepEqual(mk1, mk2) {
		t.Error("Failed to create different encryption and mac keys from two different parent keys.")
		return
	}

}

// func TestGetAuthKeys(t *testing.T) {
// 	t.Log("GetAuthKeys test")

// 	userlib.SetDebugStatus(false)

// 	//Test error is thrown for empty username and/or password
// 	string1, empty := "potatoes", ""
// 	_, err := getAuthParentKey(string1, empty)
// 	if err.Error() != Error("Username and password cannot be empty.").Error() {
// 		t.Error("Failed to throw error for empty password.")
// 		return
// 	}
// 	_, err = getAuthParentKey(empty, string1)
// 	if err.Error() != Error("Username and password cannot be empty.").Error() {
// 		t.Error("Failed to throw error for empty username.")
// 		return
// 	}
// 	_, err = getAuthParentKey(empty, empty)
// 	if err.Error() != Error("Username and password cannot be empty.").Error() {
// 		t.Error("Failed to throw error for empty username and password.")
// 		return
// 	}

// 	//Test determinism
// 	userParentKey1, _ := getAuthParentKey(string1, string1)
// 	userParentKey2, _ := getAuthParentKey(string1, string1)
// 	if !reflect.DeepEqual(userParentKey1, userParentKey2) {
// 		t.Error("Failed to deterministically create encryption and mac key from the same username and password.")
// 		return
// 	}
// 	string2 := "baked"
// 	ek1, mk1, _ = getAuthKeys(string2, string1)
// 	ek2, mk2, _ = getAuthKeys(string2, string1)
// 	if !reflect.DeepEqual(ek1, ek2) || !reflect.DeepEqual(mk1, mk2) {
// 		t.Error("Failed to deterministically create encryption and mac key from username and password.")
// 		return
// 	}
// 	string3 := "bacon"
// 	ek2, mk2, _ = getAuthKeys(string3, string1)
// 	if reflect.DeepEqual(ek1, ek2) || reflect.DeepEqual(mk1, mk2) {
// 		t.Error("Failed to create different encryption and mac keys from different username and same password.")
// 		return
// 	}
// 	string4 := "sushiroll"
// 	ek2, mk2, _ = getAuthKeys(string3, string4)
// 	if reflect.DeepEqual(ek1, ek2) || reflect.DeepEqual(mk1, mk2) {
// 		t.Error("Failed to create different encryption and mac keys from different username and different password.")
// 		return
// 	}

// 	//Test length of keys
// 	if len(ek1) != userlib.AESKeySizeBytes {
// 		t.Error("Failed to create encryption key with corret size of AESKeySize = 16.")
// 		return
// 	}
// 	if len(mk1) != userlib.AESKeySizeBytes {
// 		t.Error("Failed to create mac key with corret size of AESKeySize = 16.")
// 		return
// 	}

// }

func TestGetEncrypted(t *testing.T) {
	clear()
	t.Log("GetVerified test")

	userlib.SetDebugStatus(false)

	msg := []byte("Hello World") // size = 11 bytes
	t.Log("MSG: ", msg)

	ek := userlib.RandomBytes(16)

	encryptedMsg, err1 := getEncrypted(msg, ek)
	if err1 != nil {
		t.Error("Failed to encrypt MSG.", err1)
		return
	}
	if len(encryptedMsg) != 32 { // pt (11) + pad (5) + iv (16) = 32
		t.Error("Failed to correctly encrypt MSG. Size of encryption: ", len(encryptedMsg))
		return
	}

}

func TestGetMACed(t *testing.T) {
	clear()
	t.Log("GetVerified test")

	userlib.SetDebugStatus(false)

	msg := []byte("Get to tha choppa!")
	// t.Log("MSG: ", msg)

	msgSize := len(msg)
	mk := userlib.RandomBytes(16)

	tag, _ := userlib.HMACEval(mk, msg)
	// t.Log("TAG: ", tag)

	msgWithTag := make([]byte, msgSize+64)
	copy(msgWithTag, msg)
	copy(msgWithTag[msgSize:], tag)

	macedMsg, err1 := getMACed(msg, mk)
	if err1 != nil {
		t.Error("Failed to MAC a message.", err1)
		return
	}
	if !reflect.DeepEqual(macedMsg, msgWithTag) {
		t.Error("Failed to correctly MAC amessage.")
		t.Error("MACed MSG: ", macedMsg)
		t.Error("MSG with tag attached: ", msgWithTag)
		return
	}
}

func TestEncThenMac(t *testing.T) {
	t.Log("EncThenMac test")

	userlib.SetDebugStatus(false)

	//Test error is thrown for empty message
	msg := []byte("")
	_, err := encryptThenMac(msg, userlib.RandomBytes(16))
	if err.Error() != Error("Plaintext cannot be empty").Error() {
		t.Error("Failed to throw error for empty message. ")
		return
	}

	msg = []byte("Hello World")

	// //Test error is thrown for empty encryption key and empty mac key
	// empty_key := userlib.RandomBytes(0)
	// valid_key := userlib.RandomBytes(16)
	// _, err = encryptThenMac(msg, empty_key, valid_key)
	// if err.Error() != Error("Encryption key must have a length of 16.").Error() {
	// 	t.Error("Failed to throw error for empty encryption key.", err)
	// 	return
	// }
	// _, err = encryptThenMac(msg, valid_key, empty_key)
	// if err.Error() != Error("Mac key must have a length of 16.").Error() {
	// 	t.Error("Failed to throw error for empty mac key.")
	// 	return
	// }

	//Test error is thrown for encryption keys that do not have length of 16 bytes
	// invalid_key := userlib.RandomBytes(15)
	// _, err = encryptThenMac(msg, invalid_key, valid_key)
	// if err.Error() != Error("Both keys must have a length of 16.").Error() {
	// 	t.Error("Failed to throw error for encryption key of length 15.")
	// 	return
	// }
	// _, err = encryptThenMac(msg, valid_key, invalid_key)
	// if err.Error() != Error("Both keys must have a length of 16.").Error() {
	// 	t.Error("Failed to throw error for mac key of length 15.")
	// 	return
	// }
	// invalid_key = userlib.RandomBytes(17)
	// _, err = encryptThenMac(msg, invalid_key, valid_key)
	// if err.Error() != Error("Both keys must have a length of 16.").Error() {
	// 	t.Error("Failed to throw error for encryption key of length 17.")
	// 	return
	// }
	// _, err = encryptThenMac(msg, valid_key, invalid_key)
	// if err.Error() != Error("Both keys must have a length of 16.").Error() {
	// 	t.Error("Failed to throw error for mac key of length 17.")
	// 	return
	// }

	//Test correctness
	parentKey := userlib.RandomBytes(16)
	msgBytes := []byte(msg) //msg="Hello World" has a size of 11 bytes
	result, _ := encryptThenMac(msgBytes, parentKey)
	if len(result) != 96 {
		t.Error("Inccorect length of result.") //11 (pt) + 5 (pad) + 16 (iv) + 64 (tag) = 96 bytes
		return
	}

}

func TestGetVerified(t *testing.T) {
	clear()
	t.Log("GetVerified test")

	userlib.SetDebugStatus(false)

	msg := []byte("Get to tha choppa!")
	// t.Log("MSG: ", msg)

	msgSize := len(msg)
	mk := userlib.RandomBytes(16)

	tag, _ := userlib.HMACEval(mk, msg)
	// t.Log("TAG: ", tag)

	msgWithTag := make([]byte, msgSize+64)
	copy(msgWithTag, msg)
	copy(msgWithTag[msgSize:], tag)
	// t.Log("MSG with tag attatched: ", msgWithTag)

	verifiedMsg, err1 := getVerified(msgWithTag, mk)
	if err1 != nil {
		t.Error("Failed to verify an untampered message.", err1)
		return
	}
	if !reflect.DeepEqual(msg, verifiedMsg) {
		t.Error("Failed to correctly return the message.", err1)
		return
	}

	tamperedMsg := msg
	tamperedMsg[10] = byte('e')
	tamperedMsgWithTag := make([]byte, msgSize+64)
	copy(tamperedMsgWithTag, msg)
	copy(tamperedMsgWithTag[msgSize:], tag)
	// t.Log("Tampered MSG with tag attatched: ", msgWithTag)
	_, err2 := getVerified(tamperedMsgWithTag, mk)
	if err2.Error() != Error("Data's integrity has been compromised.").Error() {
		t.Error("Failed to detect compromised message.")
		return
	}

}

func TestGetDecrypted(t *testing.T) {
	clear()
	t.Log("GetDecrypted test")

	userlib.SetDebugStatus(false)

	msg := []byte("Hello World") // size = 11 bytes
	ek := userlib.RandomBytes(16)
	encrypted, err := getEncrypted(msg, ek)
	if err != nil {
		t.Error("Failed to encrypt.", err)
		return
	}
	decrypted, err := getDecrypted(encrypted, ek)
	if err != nil {
		t.Error("Failed to decrypt.", err)
		return
	}
	if !reflect.DeepEqual(msg, decrypted) {
		t.Error("Failed to correctly decrypt.")
		t.Error("MSG: ", msg)
		t.Error("Decrypted MSG: ", decrypted)
		return
	}

}

func TestEncDec(t *testing.T) {
	t.Log("Encryption and Decryption test")

	userlib.SetDebugStatus(false)

	msg := []byte("This is a very secret secret.")
	parentKey := userlib.RandomBytes(16)

	crypted, _ := encryptThenMac(msg, parentKey)
	decrypted, err := verifyThendecrypt(crypted, parentKey)
	if !reflect.DeepEqual(msg, decrypted) {
		t.Error("Nope.", err)
		return
	}

	tampered := crypted
	tampered[10] = byte('c')
	_, err = verifyThendecrypt(tampered, parentKey)
	if err.Error() != Error("Data's integrity has been compromised.").Error() {
		t.Error("Failed to detect compromised integrity.")
		return
	}

}

func TestGetUser(t *testing.T) {
	clear()
	t.Log("GerUser test")

	userlib.SetDebugStatus(false)

	alice, _ := InitUser("alice", "fubar")
	session1, err := GetUser("alice", "fubar")
	if err != nil {
		t.Error("Failed to get user for session 1.", err)
		return
	}
	session2, err := GetUser("alice", "fubar")
	if err != nil {
		t.Error("Failed to get user for session 2.", err)
		return
	}

	//Test Correctness
	if !reflect.DeepEqual(alice, session1) {
		t.Error("Failed to get Alice's user struct for session 1.")
		return
	}
	if !reflect.DeepEqual(alice, session2) {
		t.Error("Failed to get Alice's user struct for session 2.")
		return
	}

	//Test nonexistant user
	_, err = GetUser("bob", "fubar")
	if err.Error() != Error("User with given username does not exists.").Error() {
		t.Error("Failed to recognize nonexistant user.")
		return
	}

	//Test invalid password
	_, err = GetUser("alice", "Fubar")
	if err == nil {
		t.Error("Failed to recognize incorrect password.")
		return
	}

}
